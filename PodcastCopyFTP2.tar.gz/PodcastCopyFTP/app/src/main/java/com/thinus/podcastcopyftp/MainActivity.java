package com.thinus.podcastcopyftp;

import android.os.AsyncTask;
import android.os.Environment;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.os.AsyncTask;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.util.Date;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;


public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button uploadButton = (Button) findViewById(R.id.buttonUpload);
        uploadButton.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        buttonuploadClick(v);
                    }
                }
        );
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void buttonuploadClick(View view) {
        ((TextView) findViewById(R.id.textViewMemo)).setText("");

        new doUploadAsync().execute(((EditText) findViewById(R.id.editTextFTPServer)).getText(), ((EditText) findViewById(R.id.editTextPodCasts)).getText());
    }




    class doUploadAsync extends AsyncTask {

        class fileRecord{
            String Name;
            Date date;
            String Folder;
            String FolderDate;

        }
        private Exception exception;
        EditText editTextServer;
        TextView memo;
        doUploadAsync() {
            editTextServer = (EditText) findViewById(R.id.editTextFTPServer);
            memo = (TextView) findViewById(R.id.textViewMemo);
        }

        @Override
        protected Object doInBackground(Object[] params) {
            try {
                //local files
                File extStorageDirectory = Environment.getExternalStorageDirectory();
                String path = extStorageDirectory.toString()+"/Android/data/de.danoeh.antennapod/files/media/";
                publishProgress("Checking " + path);

                addLocalFiles(path);

                publishProgress("Creating FTP Object....");
                FTPClient ftpClient = new FTPClient();
                publishProgress("Server IP: " + params[0]);
                publishProgress("Working folder: " + params[1]);

                String[] FTPServerIPs = params[0].toString().split("\\.");
                String WorkingDir = params[1].toString();
                publishProgress(FTPServerIPs.length);
                publishProgress("Parsing address "+FTPServerIPs[0]+"."+FTPServerIPs[1]+"."+FTPServerIPs[2]+"."+FTPServerIPs[3]+"."+"....");
                //InetAddress ia = InetAddress.getByAddress(new byte[]{(byte) 192, (byte) 168, (byte) 1, (byte) 106});
                InetAddress ia = InetAddress.getByAddress(new byte[]{(byte)Integer.parseInt(FTPServerIPs[0]), (byte)Integer.parseInt(FTPServerIPs[1]),(byte)Integer.parseInt(FTPServerIPs[2]),(byte)Integer.parseInt(FTPServerIPs[3])});
                publishProgress("Connecting....");
                ftpClient.connect(ia);
                publishProgress("Status: "+ ftpClient.getStatus());
                publishProgress("Logging in....");
                if (ftpClient.login("pi", "M@t0rb1k3pi")) {
                    publishProgress("...done.");
                    publishProgress("Status: " + ftpClient.getStatus());
                    publishProgress("Changing Working Dir to " + WorkingDir + "....");
                    if (ftpClient.changeWorkingDirectory(WorkingDir))
                        publishProgress("...done.");
                    publishProgress("Getting filenames....");
                    String[] files = ftpClient.listNames();
                    if (files != null) {
                        for (String fileName : files) {
                            publishProgress("File: " + fileName);
                        }
                    }
//            ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
//            BufferedInputStream buffIn=null;
//            buffIn=new BufferedInputStream(new FileInputStream(file));
//            ftpClient.enterLocalPassiveMode();
//            ftpClient.storeFile("test.txt", buffIn);
//            buffIn.close();
                    publishProgress("Logout....");
                    ftpClient.logout();
                }
                else
                {
                    publishProgress("...Could not login");
                }
                publishProgress("Disconnect...");
                ftpClient.disconnect();
                publishProgress("Disconnected...DONE");
            } catch (Exception e) {
                StackTraceElement[] ste = e.getStackTrace();
                publishProgress("Exception: " + e.toString() + "\n\n" + ste[0].toString());
                e.printStackTrace();

            }
            return null;
        }

        private void addLocalFiles(String path){
            File f = new File(path);
            publishProgress("Got " + f.getName() + " - " + f.getPath());
            publishProgress("Getting list of Files");
            File file[] = f.listFiles();
            publishProgress("Files: "+ file.length);
            for (int i=0; i < file.length; i++)
            {
                if (file[i].isDirectory())
                    publishProgress("Directory: " + file[i].getName());
                    addLocalFiles(file[i].getPath());
                if (file[i].isFile())
                    publishProgress("File: " + file[i].getName());
                //Log.d("Files", "FileName:" + file[i].getName());
            }
        }

        protected void onProgressUpdate(Object[] params) {
            // TODO Auto-generated method stub
            super.onProgressUpdate(params);
            memo.setText(memo.getText() + "\n(" + memo.getText().length() + ") " + params[0]);
        }

        protected void onPostExecute(Object a) {
            // TODO: check this.exception
            // TODO: do something with the feed
        }
    }
}