package com.thinus.wallet;

import java.util.Date;

/**
 * Created by thinus on 2014/12/26.
 */
public class Transction {
    private int _id;
    private double _amount;
    private int _categoryId;
    private String _account;
    private String _description;
    private Date _date;

    public int getId()
    {
        return _id;
    }
    public double getAmount()
    {
        return _amount;
    }
    public int getCategoryId()
    {
        return _categoryId;
    }
    public String getAccount()
    {
        return _account;
    }
    public String getDescription()
    {
        return _description;
    }
    public Date getDate()
    {
        return _date;
    }

    public String getCategoryName()
    {
        return CategoryListActivity.getCategoryName(_id);
    }

    Transction(int Id, double amount, int categoryId, String account, String description, Date date)
    {
        if (Id == 0) {
            _id = getNextID();
        } else {
            _id = Id;
        }
        _amount = amount;
        _categoryId = categoryId;
        _account = account;
        _description = description;
        _date = date;
    }

    private int getNextID(){
        return 0;
    }

}
