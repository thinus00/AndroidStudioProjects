package com.thinus.wallet;

/**
 * Created by thinus on 2014/12/27.
 */

public class Category {

    public enum CategoryType {
        Expense,
        Income
    }

    private int _id;
    private String _name;
    private CategoryType _catType;
    private double _budget;

    public int getId()
    {
        return _id;
    }
    public String getName()
    {
        return _name;
    }
    public CategoryType getCatType()
    {
        return _catType;
    }
    public double getBudget()
    {
        return _budget;
    }

    Category(int Id, String Name, CategoryType catType, double Budget)
    {
        if (Id == 0) {
            _id = getNextID();
        } else {
            _id = Id;
        }
        _name = Name;
        _catType = catType;
        _budget = Budget;
    }

    private int getNextID(){
        return 0;
    }
}
