package com.thinus.wallet;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 * Created by thinus on 2014/12/27.
 */

public class CustomBaseAdapterCategoryList extends BaseAdapter {
    private static ArrayList<Category> searchArrayList;

    private LayoutInflater mInflater;

    public CustomBaseAdapterCategoryList(Context context, ArrayList<Category> results) {
        searchArrayList = results;
        mInflater = LayoutInflater.from(context);
    }

    public int getCount() {
        return searchArrayList.size();
    }

    public Object getItem(int position) {
        return searchArrayList.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.custom_list_item_view, null);
            holder = new ViewHolder();
            holder.txtName = (TextView) convertView.findViewById(R.id.name);
            holder.txtType = (TextView) convertView.findViewById(R.id.type);
            holder.txtBudget = (TextView) convertView.findViewById(R.id.budget);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.txtName.setText(searchArrayList.get(position).getName());
        holder.txtType.setText(searchArrayList.get(position).getCatType().toString());
        holder.txtBudget.setText("R" + String.valueOf(searchArrayList.get(position).getBudget()));

        return convertView;
    }

    static class ViewHolder {
        TextView txtName;
        TextView txtType;
        TextView txtBudget;
    }

}
