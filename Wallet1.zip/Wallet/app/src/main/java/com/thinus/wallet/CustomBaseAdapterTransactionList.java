package com.thinus.wallet;

/**
 * Created by thinus on 2014/12/26.
 */


import android.text.format.DateFormat;
import android.widget.BaseAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.text.SimpleDateFormat;
import android.content.Context;
import android.widget.TextView;


public class CustomBaseAdapterTransactionList extends BaseAdapter {
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    private static ArrayList<Transction> searchArrayList;

    private LayoutInflater mInflater;

    public CustomBaseAdapterTransactionList(Context context, ArrayList<Transction> results) {
        searchArrayList = results;
        mInflater = LayoutInflater.from(context);
    }

    public int getCount() {
        return searchArrayList.size();
    }

    public Object getItem(int position) {
        return searchArrayList.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.custom_list_item_view, null);
            holder = new ViewHolder();
            holder.txtCategory = (TextView) convertView.findViewById(R.id.category);
            holder.txtAmount = (TextView) convertView.findViewById(R.id.amount);
            holder.txtDate = (TextView) convertView.findViewById(R.id.date);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.txtCategory.setText(searchArrayList.get(position).getCategoryName());
        holder.txtAmount.setText("R" + String.valueOf(searchArrayList.get(position).getAmount()));
        holder.txtDate.setText(dateFormat.format(searchArrayList.get(position).getDate()));
        //holder.txtDate.setText(DateFormat.format("yy-MM-dd", searchArrayList.get(position).getDate()).toString());

        return convertView;
    }

    static class ViewHolder {
        TextView txtCategory;
        TextView txtAmount;
        TextView txtDate;
    }

}
