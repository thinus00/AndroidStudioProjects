package com.thinus.wallet;

import android.app.DatePickerDialog;
import android.app.DialogFragment;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.app.Dialog;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class TransactionAddActivity extends ActionBarActivity {
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction_add);

        final Calendar calendar = Calendar.getInstance();
        int yy = calendar.get(Calendar.YEAR);
        int mm = calendar.get(Calendar.MONTH);
        int dd = calendar.get(Calendar.DAY_OF_MONTH);
        EditText _editText_date = (EditText)findViewById(R.id.editText_date);
        _editText_date.setText(yy+"/"+mm+"/"+dd);

        Button button = (Button)findViewById(R.id.button_save);
        button.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        EditText editText_amount = (EditText)findViewById(R.id.editText_amount);
                        EditText editText_category = (EditText)findViewById(R.id.editText_category);
                        EditText editText_account = (EditText)findViewById(R.id.editText_account);
                        EditText editText_description = (EditText)findViewById(R.id.editText_description);
                        EditText editText_date = (EditText)findViewById(R.id.editText_date);
                        String yy;
                        String mm;
                        String dd;
                        try {
                            String[] yymmdd = editText_date.getText().toString().split("-");
                            yy = yymmdd[0];
                            mm = yymmdd[1];
                            dd = yymmdd[2];
                        }
                        catch (Exception ex)
                        {
                            yy = "2010";
                            mm = "01";
                            dd = "01";
                        }
                        Transction sr1 = null;
                        try {
                            sr1 = new Transction(0,//get next ID
                                    Double.parseDouble(editText_amount.getText().toString()),
                                    CategoryListActivity.getCategoryId(editText_category.getText().toString()),
                                    editText_account.getText().toString(),
                                    editText_description.getText().toString(),
                                    dateFormat.parse(yy+"-"+mm+"-"+dd));
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        TransactionListActivity.transactionItems.add(sr1);
                        finish();
                    }
                }
        );
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_transaction_add, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void selectDate(View view){
        DialogFragment newFragment = new SelectDateFragment();
        newFragment.show(getFragmentManager(), "DatePicker");
    }

    public void populateSetDate(int year, int month, int day){
        EditText _editText_date = (EditText)findViewById(R.id.editText_date);
        _editText_date.setText(year+"-"+month+"-"+day);
    }

    public class SelectDateFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener{
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState){
            final Calendar calendar = Calendar.getInstance();
            int yy = calendar.get(Calendar.YEAR);
            int mm = calendar.get(Calendar.MONTH);
            int dd = calendar.get(Calendar.DAY_OF_MONTH);
            return new DatePickerDialog(getActivity(), this, yy,mm,dd);
        }
        public void onDateSet(DatePicker view, int yy, int mm, int dd)
        {
            populateSetDate(yy,mm+1,dd);
        }
    }
}
