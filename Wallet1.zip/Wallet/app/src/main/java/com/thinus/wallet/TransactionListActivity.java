package com.thinus.wallet;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
//import android.widget.ArrayAdapter;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class TransactionListActivity extends ActionBarActivity {

    public static ArrayList<Transction> transactionItems;
    private CustomBaseAdapterTransactionList baseTransactionListAdapter;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction_list);
        // Get ListView object from xml

        transactionItems = new ArrayList<Transction>();

        //CategoryListActivity.AddTestArray();
        AddTestArray();

        final ListView lv1 = (ListView) findViewById(R.id.listViewTransactions);
        baseTransactionListAdapter = new CustomBaseAdapterTransactionList(this, transactionItems);
        lv1.setAdapter(baseTransactionListAdapter);

        lv1.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> a, View v, int position, long id) {
                Object o = lv1.getItemAtPosition(position);
                Transction fullObject = (Transction)o;
                Toast.makeText(getApplicationContext(), "You have chosen: " + " " + CategoryListActivity.getCategoryName(fullObject.getCategoryId()), Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(getApplicationContext(), "Refreshing list", Toast.LENGTH_LONG).show();
        refreshList();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_transaction_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        if (id == R.id.categories) {
            Intent intent = new Intent(TransactionListActivity.this, CategoryListActivity.class);
            this.startActivity(intent);
            return true;
        }

        if (id == R.id.add_transaction) {
            Intent intent = new Intent(TransactionListActivity.this, TransactionAddActivity.class);
            this.startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void AddTestArray(){

        Transction sr1 = null;
        try {
            sr1 = new Transction(1, 450.52, CategoryListActivity.getCategoryId("Fuel"), "Cheque", "ULP95", dateFormat.parse("2014-12-25"));
            transactionItems.add(sr1);

            sr1 = new Transction(2, 3600.52, CategoryListActivity.getCategoryId("Car"), "Cheque", "", dateFormat.parse("2014-12-25"));
            transactionItems.add(sr1);

            sr1 = new Transction(3, 20, CategoryListActivity.getCategoryId("Fast Food"), "Cheque", "Mcd's", dateFormat.parse("2014-12-26"));
            transactionItems.add(sr1);

            sr1 = new Transction(4, 300, CategoryListActivity.getCategoryId("Salary"), "Cheque", "207.2kw", dateFormat.parse("2014-12-26"));
            transactionItems.add(sr1);
        } catch (ParseException e) {
            e.printStackTrace();
        }

    }

    public void refreshList()
    {
        baseTransactionListAdapter.notifyDataSetChanged();
    }
}


