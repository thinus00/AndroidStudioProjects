package com.thinus.wallet;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


public class CategoryListActivity extends ActionBarActivity {

    public static ArrayList<Category> categoryItems;
    private CustomBaseAdapterCategoryList baseCategoryListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_list);

        categoryItems.add(new Category(0, "Unknown", Category.CategoryType.Expense, 0));

        final ListView lv1 = (ListView) findViewById(R.id.listViewTransactions);
        baseCategoryListAdapter = new CustomBaseAdapterCategoryList(this, categoryItems);
        lv1.setAdapter(baseCategoryListAdapter);

        lv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> a, View v, int position, long id) {
                Object o = lv1.getItemAtPosition(position);
                Transction fullObject = (Transction)o;
                Toast.makeText(getApplicationContext(), "You have chosen: " + " " + CategoryListActivity.getCategoryName(fullObject.getCategoryId()), Toast.LENGTH_LONG).show();
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_category_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        if (id == R.id.add_category) {
            //Intent intent = new Intent(CategoryListActivity.this, TransactionAddActivity.class);
            //this.startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public static int getCategoryId(String catName){
        for (Category s : categoryItems){

            if (s.getName().equals(catName))
                return s.getId();
        }
        return 0;
    }

    public static String getCategoryName(int Id){
        for (Category s : categoryItems){

            if (s.getId() == (Id))
                return s.getName();
        }
        return "";
    }

    public static void AddTestArray() {

        Category sr1 = null;
        sr1 = new Category(1, "Fuel", Category.CategoryType.Expense, 3000);
        categoryItems.add(sr1);

        sr1 = new Category(2, "Car", Category.CategoryType.Expense, 3652);
        categoryItems.add(sr1);

        sr1 = new Category(3, "Fast Food", Category.CategoryType.Expense, 500);
        categoryItems.add(sr1);

        sr1 = new Category(4, "Salary", Category.CategoryType.Income, 10000);
        categoryItems.add(sr1);

    }

    public void refreshList()
    {
        baseCategoryListAdapter.notifyDataSetChanged();
    }

}
